package com.newlecture.di.ui;

import com.newlecture.di.entity.Exam;

public class InlineExamConsole implements ExamConsole {
	
	private Exam exam;		
	
	public InlineExamConsole() {
		System.out.println("constructor");	
	}	
		
	public InlineExamConsole(Exam exam) {	
		System.out.println("overloaded constructor");
		this.exam = exam;
	}
	
	@Override
	public void print() {
		if(exam == null)
			System.out.printf("total is %d, avg is %f\n", 0, 0.0);
		else
			System.out.printf("total is %d, avg is %f\n", exam.total(), exam.avg());
	}
	
	
	@Override
	public void setExam(Exam exam) {
		System.out.println("setter");
		this.exam = exam;
	}

}
