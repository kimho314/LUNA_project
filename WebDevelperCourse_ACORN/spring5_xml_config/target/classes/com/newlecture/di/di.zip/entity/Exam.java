package com.newlecture.di.entity;

public interface Exam {
	int total();
	float avg();
}
