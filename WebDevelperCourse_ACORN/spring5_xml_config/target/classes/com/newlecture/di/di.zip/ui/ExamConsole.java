package com.newlecture.di.ui;

import com.newlecture.di.entity.Exam;

public interface ExamConsole {
	void print();
	void setExam(Exam exam);
}
